/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getclan.ranking;

public enum RankType {
    KILLS,
    DEATHS,
    USER_POINTS,
    CLAN_POINTS;

}

