/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getclan.core.upgrade;

public enum UpgradeType {
    DROP_BOOST,
    POINTS_BOOST,
    MEMBERS;

}

