/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.exc;

import dev.gether.getconfig.jackson.core.JsonLocation;
import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;
import java.io.Closeable;

public class MismatchedInputException
extends JsonMappingException {
    protected Class<?> _targetType;

    protected MismatchedInputException(JsonParser p, String msg) {
        this(p, msg, (JavaType)null);
    }

    protected MismatchedInputException(JsonParser p, String msg, JsonLocation loc) {
        super((Closeable)p, msg, loc);
    }

    protected MismatchedInputException(JsonParser p, String msg, Class<?> targetType) {
        super(p, msg);
        this._targetType = targetType;
    }

    protected MismatchedInputException(JsonParser p, String msg, JavaType targetType) {
        super(p, msg);
        this._targetType = ClassUtil.rawClass(targetType);
    }

    @Deprecated
    public static MismatchedInputException from(JsonParser p, String msg) {
        return MismatchedInputException.from(p, (Class)null, msg);
    }

    public static MismatchedInputException from(JsonParser p, JavaType targetType, String msg) {
        return new MismatchedInputException(p, msg, targetType);
    }

    public static MismatchedInputException from(JsonParser p, Class<?> targetType, String msg) {
        return new MismatchedInputException(p, msg, targetType);
    }

    public MismatchedInputException setTargetType(JavaType t) {
        this._targetType = t.getRawClass();
        return this;
    }

    public Class<?> getTargetType() {
        return this._targetType;
    }
}

