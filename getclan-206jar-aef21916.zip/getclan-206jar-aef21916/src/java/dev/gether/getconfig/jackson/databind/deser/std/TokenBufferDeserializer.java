/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.deser.std;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.annotation.JacksonStdImpl;
import dev.gether.getconfig.jackson.databind.deser.std.StdScalarDeserializer;
import dev.gether.getconfig.jackson.databind.type.LogicalType;
import dev.gether.getconfig.jackson.databind.util.TokenBuffer;
import java.io.IOException;

@JacksonStdImpl
public class TokenBufferDeserializer
extends StdScalarDeserializer<TokenBuffer> {
    private static final long serialVersionUID = 1L;

    public TokenBufferDeserializer() {
        super(TokenBuffer.class);
    }

    @Override
    public LogicalType logicalType() {
        return LogicalType.Untyped;
    }

    @Override
    public TokenBuffer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return ctxt.bufferForInputBuffering(p).deserialize(p, ctxt);
    }
}

