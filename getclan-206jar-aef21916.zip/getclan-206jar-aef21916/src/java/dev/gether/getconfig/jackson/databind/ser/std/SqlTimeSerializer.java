/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.reflect.Type
 *  java.sql.Time
 */
package dev.gether.getconfig.jackson.databind.ser.std;

import dev.gether.getconfig.jackson.core.JsonGenerator;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.JsonNode;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.annotation.JacksonStdImpl;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonValueFormat;
import dev.gether.getconfig.jackson.databind.ser.std.StdScalarSerializer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.sql.Time;

@JacksonStdImpl
public class SqlTimeSerializer
extends StdScalarSerializer<Time> {
    public SqlTimeSerializer() {
        super(Time.class);
    }

    @Override
    public void serialize(Time value, JsonGenerator g, SerializerProvider provider) throws IOException {
        g.writeString(value.toString());
    }

    @Override
    @Deprecated
    public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
        return this.createSchemaNode("string", true);
    }

    @Override
    public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
        this.visitStringFormat(visitor, typeHint, JsonValueFormat.DATE_TIME);
    }
}

