/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.introspect;

import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMember;

public interface WithMember<T> {
    public T withMember(AnnotatedMember var1);
}

