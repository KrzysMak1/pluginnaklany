/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.AnnotatedElement
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package dev.gether.getconfig.jackson.databind.introspect;

import dev.gether.getconfig.jackson.databind.AnnotationIntrospector;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedClass;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedConstructor;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMember;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMethod;
import dev.gether.getconfig.jackson.databind.introspect.AnnotationCollector;
import dev.gether.getconfig.jackson.databind.introspect.AnnotationMap;
import dev.gether.getconfig.jackson.databind.introspect.CollectorBase;
import dev.gether.getconfig.jackson.databind.introspect.MemberKey;
import dev.gether.getconfig.jackson.databind.introspect.MethodGenericTypeResolver;
import dev.gether.getconfig.jackson.databind.introspect.TypeResolutionContext;
import dev.gether.getconfig.jackson.databind.type.TypeFactory;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class AnnotatedCreatorCollector
extends CollectorBase {
    private final TypeResolutionContext _typeContext;
    private final boolean _collectAnnotations;
    private AnnotatedConstructor _defaultConstructor;

    AnnotatedCreatorCollector(AnnotationIntrospector intr, TypeResolutionContext tc, boolean collectAnnotations) {
        super(intr);
        this._typeContext = tc;
        this._collectAnnotations = collectAnnotations;
    }

    public static AnnotatedClass.Creators collectCreators(AnnotationIntrospector intr, TypeFactory typeFactory, TypeResolutionContext tc, JavaType type, Class<?> primaryMixIn, boolean collectAnnotations) {
        return new AnnotatedCreatorCollector(intr, tc, collectAnnotations |= primaryMixIn != null).collect(typeFactory, type, primaryMixIn);
    }

    AnnotatedClass.Creators collect(TypeFactory typeFactory, JavaType type, Class<?> primaryMixIn) {
        List<AnnotatedConstructor> constructors = this._findPotentialConstructors(type, primaryMixIn);
        List<AnnotatedMethod> factories = this._findPotentialFactories(typeFactory, type, primaryMixIn);
        if (this._collectAnnotations) {
            if (this._defaultConstructor != null && this._intr.hasIgnoreMarker(this._defaultConstructor)) {
                this._defaultConstructor = null;
            }
            int i = constructors.size();
            while (--i >= 0) {
                if (!this._intr.hasIgnoreMarker((AnnotatedMember)constructors.get(i))) continue;
                constructors.remove(i);
            }
            i = factories.size();
            while (--i >= 0) {
                if (!this._intr.hasIgnoreMarker((AnnotatedMember)factories.get(i))) continue;
                factories.remove(i);
            }
        }
        return new AnnotatedClass.Creators(this._defaultConstructor, constructors, factories);
    }

    private List<AnnotatedConstructor> _findPotentialConstructors(JavaType type, Class<?> primaryMixIn) {
        int ctorCount;
        List result;
        ClassUtil.Ctor defaultCtor = null;
        ArrayList ctors = null;
        if (!type.isEnumType()) {
            ClassUtil.Ctor[] declaredCtors;
            for (ClassUtil.Ctor ctor : declaredCtors = ClassUtil.getConstructors(type.getRawClass())) {
                if (!AnnotatedCreatorCollector.isIncludableConstructor(ctor.getConstructor())) continue;
                if (ctor.getParamCount() == 0) {
                    defaultCtor = ctor;
                    continue;
                }
                if (ctors == null) {
                    ctors = new ArrayList();
                }
                ctors.add((Object)ctor);
            }
        }
        if (ctors == null) {
            result = Collections.emptyList();
            if (defaultCtor == null) {
                return result;
            }
            ctorCount = 0;
        } else {
            ctorCount = ctors.size();
            result = new ArrayList(ctorCount);
            for (int i = 0; i < ctorCount; ++i) {
                result.add(null);
            }
        }
        if (primaryMixIn != null) {
            MemberKey[] ctorKeys = null;
            block2: for (ClassUtil.Ctor mixinCtor : ClassUtil.getConstructors(primaryMixIn)) {
                if (mixinCtor.getParamCount() == 0) {
                    if (defaultCtor == null) continue;
                    this._defaultConstructor = this.constructDefaultConstructor(defaultCtor, mixinCtor);
                    defaultCtor = null;
                    continue;
                }
                if (ctors == null) continue;
                if (ctorKeys == null) {
                    ctorKeys = new MemberKey[ctorCount];
                    for (int i = 0; i < ctorCount; ++i) {
                        ctorKeys[i] = new MemberKey(((ClassUtil.Ctor)ctors.get(i)).getConstructor());
                    }
                }
                MemberKey key = new MemberKey(mixinCtor.getConstructor());
                for (int i = 0; i < ctorCount; ++i) {
                    if (!key.equals(ctorKeys[i])) continue;
                    result.set(i, (Object)this.constructNonDefaultConstructor((ClassUtil.Ctor)ctors.get(i), mixinCtor));
                    continue block2;
                }
            }
        }
        if (defaultCtor != null) {
            this._defaultConstructor = this.constructDefaultConstructor(defaultCtor, null);
        }
        for (int i = 0; i < ctorCount; ++i) {
            AnnotatedConstructor ctor = (AnnotatedConstructor)result.get(i);
            if (ctor != null) continue;
            result.set(i, (Object)this.constructNonDefaultConstructor((ClassUtil.Ctor)ctors.get(i), null));
        }
        return result;
    }

    private List<AnnotatedMethod> _findPotentialFactories(TypeFactory typeFactory, JavaType type, Class<?> primaryMixIn) {
        ArrayList candidates = null;
        for (Method m : ClassUtil.getClassMethods(type.getRawClass())) {
            if (!AnnotatedCreatorCollector._isIncludableFactoryMethod(m)) continue;
            if (candidates == null) {
                candidates = new ArrayList();
            }
            candidates.add((Object)m);
        }
        if (candidates == null) {
            return Collections.emptyList();
        }
        TypeResolutionContext initialTypeResCtxt = this._typeContext;
        int factoryCount = candidates.size();
        ArrayList result = new ArrayList(factoryCount);
        for (int i = 0; i < factoryCount; ++i) {
            result.add(null);
        }
        if (primaryMixIn != null) {
            MemberKey[] methodKeys = null;
            block2: for (Method mixinFactory : primaryMixIn.getDeclaredMethods()) {
                if (!AnnotatedCreatorCollector._isIncludableFactoryMethod(mixinFactory)) continue;
                if (methodKeys == null) {
                    methodKeys = new MemberKey[factoryCount];
                    for (int i = 0; i < factoryCount; ++i) {
                        methodKeys[i] = new MemberKey((Method)candidates.get(i));
                    }
                }
                MemberKey key = new MemberKey(mixinFactory);
                for (int i = 0; i < factoryCount; ++i) {
                    if (!key.equals(methodKeys[i])) continue;
                    result.set(i, (Object)this.constructFactoryCreator((Method)candidates.get(i), initialTypeResCtxt, mixinFactory));
                    continue block2;
                }
            }
        }
        for (int i = 0; i < factoryCount; ++i) {
            AnnotatedMethod factory = (AnnotatedMethod)result.get(i);
            if (factory != null) continue;
            Method candidate = (Method)candidates.get(i);
            TypeResolutionContext typeResCtxt = MethodGenericTypeResolver.narrowMethodTypeParameters(candidate, type, typeFactory, initialTypeResCtxt);
            result.set(i, (Object)this.constructFactoryCreator(candidate, typeResCtxt, null));
        }
        return result;
    }

    private static boolean _isIncludableFactoryMethod(Method m) {
        if (!Modifier.isStatic((int)m.getModifiers())) {
            return false;
        }
        return !m.isSynthetic();
    }

    protected AnnotatedConstructor constructDefaultConstructor(ClassUtil.Ctor ctor, ClassUtil.Ctor mixin) {
        return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), this.collectAnnotations(ctor, mixin), NO_ANNOTATION_MAPS);
    }

    protected AnnotatedConstructor constructNonDefaultConstructor(ClassUtil.Ctor ctor, ClassUtil.Ctor mixin) {
        AnnotationMap[] resolvedAnnotations;
        int paramCount = ctor.getParamCount();
        if (this._intr == null) {
            return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), AnnotatedCreatorCollector._emptyAnnotationMap(), AnnotatedCreatorCollector._emptyAnnotationMaps(paramCount));
        }
        if (paramCount == 0) {
            return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), this.collectAnnotations(ctor, mixin), NO_ANNOTATION_MAPS);
        }
        Annotation[][] paramAnns = ctor.getParameterAnnotations();
        if (paramCount != paramAnns.length) {
            resolvedAnnotations = null;
            Class<?> dc = ctor.getDeclaringClass();
            if (ClassUtil.isEnumType(dc) && paramCount == paramAnns.length + 2) {
                Annotation[][] old = paramAnns;
                paramAnns = new Annotation[old.length + 2][];
                System.arraycopy((Object)old, (int)0, (Object)paramAnns, (int)2, (int)old.length);
                resolvedAnnotations = this.collectAnnotations(paramAnns, (Annotation[][])null);
            } else if (dc.isMemberClass() && paramCount == paramAnns.length + 1) {
                Annotation[][] old = paramAnns;
                paramAnns = new Annotation[old.length + 1][];
                System.arraycopy((Object)old, (int)0, (Object)paramAnns, (int)1, (int)old.length);
                paramAnns[0] = NO_ANNOTATIONS;
                resolvedAnnotations = this.collectAnnotations(paramAnns, (Annotation[][])null);
            }
            if (resolvedAnnotations == null) {
                throw new IllegalStateException(String.format((String)"Internal error: constructor for %s has mismatch: %d parameters; %d sets of annotations", (Object[])new Object[]{ctor.getDeclaringClass().getName(), paramCount, paramAnns.length}));
            }
        } else {
            resolvedAnnotations = this.collectAnnotations(paramAnns, mixin == null ? (Annotation[][])null : mixin.getParameterAnnotations());
        }
        return new AnnotatedConstructor(this._typeContext, ctor.getConstructor(), this.collectAnnotations(ctor, mixin), resolvedAnnotations);
    }

    protected AnnotatedMethod constructFactoryCreator(Method m, TypeResolutionContext typeResCtxt, Method mixin) {
        int paramCount = m.getParameterCount();
        if (this._intr == null) {
            return new AnnotatedMethod(typeResCtxt, m, AnnotatedCreatorCollector._emptyAnnotationMap(), AnnotatedCreatorCollector._emptyAnnotationMaps(paramCount));
        }
        if (paramCount == 0) {
            return new AnnotatedMethod(typeResCtxt, m, this.collectAnnotations((AnnotatedElement)m, (AnnotatedElement)mixin), NO_ANNOTATION_MAPS);
        }
        return new AnnotatedMethod(typeResCtxt, m, this.collectAnnotations((AnnotatedElement)m, (AnnotatedElement)mixin), this.collectAnnotations(m.getParameterAnnotations(), mixin == null ? (Annotation[][])null : mixin.getParameterAnnotations()));
    }

    private AnnotationMap[] collectAnnotations(Annotation[][] mainAnns, Annotation[][] mixinAnns) {
        if (this._collectAnnotations) {
            int count = mainAnns.length;
            AnnotationMap[] result = new AnnotationMap[count];
            for (int i = 0; i < count; ++i) {
                AnnotationCollector c = this.collectAnnotations(AnnotationCollector.emptyCollector(), mainAnns[i]);
                if (mixinAnns != null) {
                    c = this.collectAnnotations(c, mixinAnns[i]);
                }
                result[i] = c.asAnnotationMap();
            }
            return result;
        }
        return NO_ANNOTATION_MAPS;
    }

    private AnnotationMap collectAnnotations(ClassUtil.Ctor main, ClassUtil.Ctor mixin) {
        if (this._collectAnnotations) {
            AnnotationCollector c = this.collectAnnotations(main.getDeclaredAnnotations());
            if (mixin != null) {
                c = this.collectAnnotations(c, mixin.getDeclaredAnnotations());
            }
            return c.asAnnotationMap();
        }
        return AnnotatedCreatorCollector._emptyAnnotationMap();
    }

    private final AnnotationMap collectAnnotations(AnnotatedElement main, AnnotatedElement mixin) {
        AnnotationCollector c = this.collectAnnotations(main.getDeclaredAnnotations());
        if (mixin != null) {
            c = this.collectAnnotations(c, mixin.getDeclaredAnnotations());
        }
        return c.asAnnotationMap();
    }

    private static boolean isIncludableConstructor(Constructor<?> c) {
        return !c.isSynthetic();
    }
}

