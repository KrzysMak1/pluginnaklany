/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package dev.gether.getconfig.jackson.databind.deser;

import com.fasterxml.jackson.annotation.JsonFormat;
import dev.gether.getconfig.jackson.databind.AnnotationIntrospector;
import dev.gether.getconfig.jackson.databind.BeanDescription;
import dev.gether.getconfig.jackson.databind.DatabindException;
import dev.gether.getconfig.jackson.databind.DeserializationConfig;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonDeserializer;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.MapperFeature;
import dev.gether.getconfig.jackson.databind.PropertyMetadata;
import dev.gether.getconfig.jackson.databind.PropertyName;
import dev.gether.getconfig.jackson.databind.annotation.JsonPOJOBuilder;
import dev.gether.getconfig.jackson.databind.deser.AbstractDeserializer;
import dev.gether.getconfig.jackson.databind.deser.BeanDeserializer;
import dev.gether.getconfig.jackson.databind.deser.BuilderBasedDeserializer;
import dev.gether.getconfig.jackson.databind.deser.SettableAnyProperty;
import dev.gether.getconfig.jackson.databind.deser.SettableBeanProperty;
import dev.gether.getconfig.jackson.databind.deser.ValueInstantiator;
import dev.gether.getconfig.jackson.databind.deser.impl.BeanPropertyMap;
import dev.gether.getconfig.jackson.databind.deser.impl.ObjectIdReader;
import dev.gether.getconfig.jackson.databind.deser.impl.ObjectIdValueProperty;
import dev.gether.getconfig.jackson.databind.deser.impl.ValueInjector;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMember;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMethod;
import dev.gether.getconfig.jackson.databind.util.Annotations;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;
import dev.gether.getconfig.jackson.databind.util.IgnorePropertiesUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BeanDeserializerBuilder {
    protected final DeserializationConfig _config;
    protected final DeserializationContext _context;
    protected final BeanDescription _beanDesc;
    protected final Map<String, SettableBeanProperty> _properties = new LinkedHashMap();
    protected List<ValueInjector> _injectables;
    protected HashMap<String, SettableBeanProperty> _backRefProperties;
    protected HashSet<String> _ignorableProps;
    protected HashSet<String> _includableProps;
    protected ValueInstantiator _valueInstantiator;
    protected ObjectIdReader _objectIdReader;
    protected SettableAnyProperty _anySetter;
    protected boolean _ignoreAllUnknown;
    protected AnnotatedMethod _buildMethod;
    protected JsonPOJOBuilder.Value _builderConfig;

    public BeanDeserializerBuilder(BeanDescription beanDesc, DeserializationContext ctxt) {
        this._beanDesc = beanDesc;
        this._context = ctxt;
        this._config = ctxt.getConfig();
    }

    protected BeanDeserializerBuilder(BeanDeserializerBuilder src) {
        this._beanDesc = src._beanDesc;
        this._context = src._context;
        this._config = src._config;
        this._properties.putAll(src._properties);
        this._injectables = BeanDeserializerBuilder._copy(src._injectables);
        this._backRefProperties = BeanDeserializerBuilder._copy(src._backRefProperties);
        this._ignorableProps = src._ignorableProps;
        this._includableProps = src._includableProps;
        this._valueInstantiator = src._valueInstantiator;
        this._objectIdReader = src._objectIdReader;
        this._anySetter = src._anySetter;
        this._ignoreAllUnknown = src._ignoreAllUnknown;
        this._buildMethod = src._buildMethod;
        this._builderConfig = src._builderConfig;
    }

    private static HashMap<String, SettableBeanProperty> _copy(HashMap<String, SettableBeanProperty> src) {
        return src == null ? null : new HashMap(src);
    }

    private static <T> List<T> _copy(List<T> src) {
        return src == null ? null : new ArrayList(src);
    }

    public void addOrReplaceProperty(SettableBeanProperty prop, boolean allowOverride) {
        this._properties.put((Object)prop.getName(), (Object)prop);
    }

    public void addProperty(SettableBeanProperty prop) {
        SettableBeanProperty old = (SettableBeanProperty)this._properties.put((Object)prop.getName(), (Object)prop);
        if (old != null && old != prop) {
            throw new IllegalArgumentException("Duplicate property '" + prop.getName() + "' for " + this._beanDesc.getType());
        }
    }

    public void addBackReferenceProperty(String referenceName, SettableBeanProperty prop) throws JsonMappingException {
        if (this._backRefProperties == null) {
            this._backRefProperties = new HashMap(4);
        }
        if (this._config.canOverrideAccessModifiers()) {
            try {
                prop.fixAccess(this._config);
            }
            catch (IllegalArgumentException e) {
                this._handleBadAccess(e);
            }
        }
        this._backRefProperties.put((Object)referenceName, (Object)prop);
    }

    public void addInjectable(PropertyName propName, JavaType propType, Annotations contextAnnotations, AnnotatedMember member, Object valueId) throws JsonMappingException {
        if (this._injectables == null) {
            this._injectables = new ArrayList();
        }
        if (this._config.canOverrideAccessModifiers()) {
            try {
                member.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
            }
            catch (IllegalArgumentException e) {
                this._handleBadAccess(e);
            }
        }
        this._injectables.add((Object)new ValueInjector(propName, propType, member, valueId));
    }

    public void addIgnorable(String propName) {
        if (this._ignorableProps == null) {
            this._ignorableProps = new HashSet();
        }
        this._ignorableProps.add((Object)propName);
    }

    public void addIncludable(String propName) {
        if (this._includableProps == null) {
            this._includableProps = new HashSet();
        }
        this._includableProps.add((Object)propName);
    }

    public void addCreatorProperty(SettableBeanProperty prop) {
        this.addProperty(prop);
    }

    public void setAnySetter(SettableAnyProperty s) {
        if (this._anySetter != null && s != null) {
            throw new IllegalStateException("_anySetter already set to non-null");
        }
        this._anySetter = s;
    }

    public void setIgnoreUnknownProperties(boolean ignore) {
        this._ignoreAllUnknown = ignore;
    }

    public void setValueInstantiator(ValueInstantiator inst) {
        this._valueInstantiator = inst;
    }

    public void setObjectIdReader(ObjectIdReader r) {
        this._objectIdReader = r;
    }

    public void setPOJOBuilder(AnnotatedMethod buildMethod, JsonPOJOBuilder.Value config) {
        this._buildMethod = buildMethod;
        this._builderConfig = config;
    }

    public Iterator<SettableBeanProperty> getProperties() {
        return this._properties.values().iterator();
    }

    public SettableBeanProperty findProperty(PropertyName propertyName) {
        return (SettableBeanProperty)this._properties.get((Object)propertyName.getSimpleName());
    }

    public boolean hasProperty(PropertyName propertyName) {
        return this.findProperty(propertyName) != null;
    }

    public SettableBeanProperty removeProperty(PropertyName name) {
        return (SettableBeanProperty)this._properties.remove((Object)name.getSimpleName());
    }

    public SettableAnyProperty getAnySetter() {
        return this._anySetter;
    }

    public ValueInstantiator getValueInstantiator() {
        return this._valueInstantiator;
    }

    public List<ValueInjector> getInjectables() {
        return this._injectables;
    }

    public ObjectIdReader getObjectIdReader() {
        return this._objectIdReader;
    }

    public AnnotatedMethod getBuildMethod() {
        return this._buildMethod;
    }

    public JsonPOJOBuilder.Value getBuilderConfig() {
        return this._builderConfig;
    }

    public boolean hasIgnorable(String name) {
        return IgnorePropertiesUtil.shouldIgnore(name, this._ignorableProps, this._includableProps);
    }

    public JsonDeserializer<?> build() throws JsonMappingException {
        boolean anyViews;
        Collection props = this._properties.values();
        this._fixAccess((Collection<SettableBeanProperty>)props);
        BeanPropertyMap propertyMap = BeanPropertyMap.construct(this._config, (Collection<SettableBeanProperty>)props, this._collectAliases((Collection<SettableBeanProperty>)props), this._findCaseInsensitivity());
        propertyMap.assignIndexes();
        boolean bl = anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
        if (!anyViews) {
            for (SettableBeanProperty prop : props) {
                if (!prop.hasViews()) continue;
                anyViews = true;
                break;
            }
        }
        if (this._objectIdReader != null) {
            ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
            propertyMap = propertyMap.withProperty(prop);
        }
        return new BeanDeserializer(this, this._beanDesc, propertyMap, (Map<String, SettableBeanProperty>)this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, (Set<String>)this._includableProps, anyViews);
    }

    public AbstractDeserializer buildAbstract() {
        return new AbstractDeserializer(this, this._beanDesc, (Map<String, SettableBeanProperty>)this._backRefProperties, this._properties);
    }

    public JsonDeserializer<?> buildBuilderBased(JavaType valueType, String expBuildMethodName) throws JsonMappingException {
        boolean anyViews;
        if (this._buildMethod == null) {
            if (!expBuildMethodName.isEmpty()) {
                this._context.reportBadDefinition(this._beanDesc.getType(), String.format((String)"Builder class %s does not have build method (name: '%s')", (Object[])new Object[]{ClassUtil.getTypeDescription(this._beanDesc.getType()), expBuildMethodName}));
            }
        } else {
            Class<?> rawValueType;
            Class<?> rawBuildType = this._buildMethod.getRawReturnType();
            if (rawBuildType != (rawValueType = valueType.getRawClass()) && !rawBuildType.isAssignableFrom(rawValueType) && !rawValueType.isAssignableFrom(rawBuildType)) {
                this._context.reportBadDefinition(this._beanDesc.getType(), String.format((String)"Build method `%s` has wrong return type (%s), not compatible with POJO type (%s)", (Object[])new Object[]{this._buildMethod.getFullName(), ClassUtil.getClassDescription(rawBuildType), ClassUtil.getTypeDescription(valueType)}));
            }
        }
        Collection props = this._properties.values();
        this._fixAccess((Collection<SettableBeanProperty>)props);
        BeanPropertyMap propertyMap = BeanPropertyMap.construct(this._config, (Collection<SettableBeanProperty>)props, this._collectAliases((Collection<SettableBeanProperty>)props), this._findCaseInsensitivity());
        propertyMap.assignIndexes();
        boolean bl = anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
        if (!anyViews) {
            for (SettableBeanProperty prop : props) {
                if (!prop.hasViews()) continue;
                anyViews = true;
                break;
            }
        }
        if (this._objectIdReader != null) {
            ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
            propertyMap = propertyMap.withProperty(prop);
        }
        return this.createBuilderBasedDeserializer(valueType, propertyMap, anyViews);
    }

    protected JsonDeserializer<?> createBuilderBasedDeserializer(JavaType valueType, BeanPropertyMap propertyMap, boolean anyViews) {
        return new BuilderBasedDeserializer(this, this._beanDesc, valueType, propertyMap, (Map<String, SettableBeanProperty>)this._backRefProperties, (Set<String>)this._ignorableProps, this._ignoreAllUnknown, (Set<String>)this._includableProps, anyViews);
    }

    protected void _fixAccess(Collection<SettableBeanProperty> mainProps) throws JsonMappingException {
        if (this._config.canOverrideAccessModifiers()) {
            for (SettableBeanProperty prop : mainProps) {
                try {
                    prop.fixAccess(this._config);
                }
                catch (IllegalArgumentException e) {
                    this._handleBadAccess(e);
                }
            }
        }
        if (this._anySetter != null) {
            try {
                this._anySetter.fixAccess(this._config);
            }
            catch (IllegalArgumentException e) {
                this._handleBadAccess(e);
            }
        }
        if (this._buildMethod != null) {
            try {
                this._buildMethod.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
            }
            catch (IllegalArgumentException e) {
                this._handleBadAccess(e);
            }
        }
    }

    protected Map<String, List<PropertyName>> _collectAliases(Collection<SettableBeanProperty> props) {
        HashMap mapping = null;
        AnnotationIntrospector intr = this._config.getAnnotationIntrospector();
        if (intr != null) {
            for (SettableBeanProperty prop : props) {
                List<PropertyName> aliases = intr.findPropertyAliases(prop.getMember());
                if (aliases == null || aliases.isEmpty()) continue;
                if (mapping == null) {
                    mapping = new HashMap();
                }
                mapping.put((Object)prop.getName(), aliases);
            }
        }
        if (mapping == null) {
            return Collections.emptyMap();
        }
        return mapping;
    }

    protected boolean _findCaseInsensitivity() {
        JsonFormat.Value format = this._beanDesc.findExpectedFormat(null);
        Boolean B = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
        return B == null ? this._config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES) : B.booleanValue();
    }

    protected void _handleBadAccess(IllegalArgumentException e0) throws JsonMappingException {
        try {
            this._context.reportBadTypeDefinition(this._beanDesc, e0.getMessage(), new Object[0]);
        }
        catch (DatabindException e) {
            if (e.getCause() == null) {
                e.initCause(e0);
            }
            throw e;
        }
    }
}

