/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Character
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.URI
 *  java.net.URISyntaxException
 *  java.nio.file.FileSystemNotFoundException
 *  java.nio.file.Path
 *  java.nio.file.Paths
 *  java.nio.file.spi.FileSystemProvider
 *  java.util.ServiceConfigurationError
 *  java.util.ServiceLoader
 */
package dev.gether.getconfig.jackson.databind.ext;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.core.JsonToken;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.deser.std.StdScalarDeserializer;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.spi.FileSystemProvider;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

public class NioPathDeserializer
extends StdScalarDeserializer<Path> {
    private static final long serialVersionUID = 1L;
    private static final boolean areWindowsFilePathsSupported;

    public NioPathDeserializer() {
        super(Path.class);
    }

    @Override
    public Path deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        URI uri;
        if (!p.hasToken(JsonToken.VALUE_STRING)) {
            return (Path)ctxt.handleUnexpectedToken(Path.class, p);
        }
        String value = p.getText();
        if (value.indexOf(58) < 0) {
            return Paths.get((String)value, (String[])new String[0]);
        }
        if (areWindowsFilePathsSupported && value.length() >= 2 && Character.isLetter((char)value.charAt(0)) && value.charAt(1) == ':') {
            return Paths.get((String)value, (String[])new String[0]);
        }
        try {
            uri = new URI(value);
        }
        catch (URISyntaxException e) {
            return (Path)ctxt.handleInstantiationProblem(this.handledType(), value, e);
        }
        try {
            return Paths.get((URI)uri);
        }
        catch (FileSystemNotFoundException cause) {
            try {
                String scheme = uri.getScheme();
                for (FileSystemProvider provider : ServiceLoader.load(FileSystemProvider.class)) {
                    if (!provider.getScheme().equalsIgnoreCase(scheme)) continue;
                    return provider.getPath(uri);
                }
                return (Path)ctxt.handleInstantiationProblem(this.handledType(), value, cause);
            }
            catch (ServiceConfigurationError e) {
                e.addSuppressed((Throwable)cause);
                return (Path)ctxt.handleInstantiationProblem(this.handledType(), value, e);
            }
        }
        catch (Exception e) {
            return (Path)ctxt.handleInstantiationProblem(this.handledType(), value, e);
        }
    }

    static {
        boolean isWindowsRootFound = false;
        for (File file : File.listRoots()) {
            String path = file.getPath();
            if (path.length() < 2 || !Character.isLetter((char)path.charAt(0)) || path.charAt(1) != ':') continue;
            isWindowsRootFound = true;
            break;
        }
        areWindowsFilePathsSupported = isWindowsRootFound;
    }
}

