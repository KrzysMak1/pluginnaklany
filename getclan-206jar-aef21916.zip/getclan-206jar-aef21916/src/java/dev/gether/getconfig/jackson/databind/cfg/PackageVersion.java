/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.cfg;

import dev.gether.getconfig.jackson.core.Version;
import dev.gether.getconfig.jackson.core.Versioned;
import dev.gether.getconfig.jackson.core.util.VersionUtil;

public final class PackageVersion
implements Versioned {
    public static final Version VERSION = VersionUtil.parseVersion("2.16.0", "dev.gether.getconfig.jackson.core", "jackson-databind");

    @Override
    public Version version() {
        return VERSION;
    }
}

