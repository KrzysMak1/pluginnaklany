/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.introspect;

import dev.gether.getconfig.jackson.core.Version;
import dev.gether.getconfig.jackson.databind.AnnotationIntrospector;
import dev.gether.getconfig.jackson.databind.cfg.PackageVersion;
import java.io.Serializable;

public abstract class NopAnnotationIntrospector
extends AnnotationIntrospector
implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final NopAnnotationIntrospector instance = new NopAnnotationIntrospector(){
        private static final long serialVersionUID = 1L;

        @Override
        public Version version() {
            return PackageVersion.VERSION;
        }
    };

    @Override
    public Version version() {
        return Version.unknownVersion();
    }
}

