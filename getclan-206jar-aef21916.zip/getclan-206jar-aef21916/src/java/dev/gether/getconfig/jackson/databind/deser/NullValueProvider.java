/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.deser;

import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.util.AccessPattern;

public interface NullValueProvider {
    public Object getNullValue(DeserializationContext var1) throws JsonMappingException;

    public AccessPattern getNullAccessPattern();

    default public Object getAbsentValue(DeserializationContext ctxt) throws JsonMappingException {
        return this.getNullValue(ctxt);
    }
}

