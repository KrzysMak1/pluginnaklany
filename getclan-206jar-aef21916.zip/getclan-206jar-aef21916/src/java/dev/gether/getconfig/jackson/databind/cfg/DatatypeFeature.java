/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.cfg;

import dev.gether.getconfig.jackson.core.util.JacksonFeature;

public interface DatatypeFeature
extends JacksonFeature {
    public int featureIndex();
}

