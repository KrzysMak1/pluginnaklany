/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.Serializable
 *  java.lang.AutoCloseable
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Set
 */
package dev.gether.getconfig.jackson.databind.jsontype;

import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.cfg.MapperConfig;
import dev.gether.getconfig.jackson.databind.jsontype.PolymorphicTypeValidator;
import java.io.Closeable;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class DefaultBaseTypeLimitingValidator
extends PolymorphicTypeValidator
implements Serializable {
    private static final long serialVersionUID = 1L;

    @Override
    public PolymorphicTypeValidator.Validity validateBaseType(MapperConfig<?> config, JavaType baseType) {
        if (this.isUnsafeBaseType(config, baseType)) {
            return PolymorphicTypeValidator.Validity.DENIED;
        }
        return PolymorphicTypeValidator.Validity.INDETERMINATE;
    }

    @Override
    public PolymorphicTypeValidator.Validity validateSubClassName(MapperConfig<?> config, JavaType baseType, String subClassName) {
        return PolymorphicTypeValidator.Validity.INDETERMINATE;
    }

    @Override
    public PolymorphicTypeValidator.Validity validateSubType(MapperConfig<?> config, JavaType baseType, JavaType subType) {
        return this.isSafeSubType(config, baseType, subType) ? PolymorphicTypeValidator.Validity.ALLOWED : PolymorphicTypeValidator.Validity.DENIED;
    }

    protected boolean isUnsafeBaseType(MapperConfig<?> config, JavaType baseType) {
        return UnsafeBaseTypes.instance.isUnsafeBaseType(baseType.getRawClass());
    }

    protected boolean isSafeSubType(MapperConfig<?> config, JavaType baseType, JavaType subType) {
        return true;
    }

    private static final class UnsafeBaseTypes {
        public static final UnsafeBaseTypes instance = new UnsafeBaseTypes();
        private final Set<String> UNSAFE = new HashSet();

        private UnsafeBaseTypes() {
            this.UNSAFE.add((Object)Object.class.getName());
            this.UNSAFE.add((Object)Closeable.class.getName());
            this.UNSAFE.add((Object)Serializable.class.getName());
            this.UNSAFE.add((Object)AutoCloseable.class.getName());
            this.UNSAFE.add((Object)Cloneable.class.getName());
            this.UNSAFE.add((Object)"java.util.logging.Handler");
            this.UNSAFE.add((Object)"javax.naming.Referenceable");
            this.UNSAFE.add((Object)"javax.sql.DataSource");
        }

        public boolean isUnsafeBaseType(Class<?> rawBaseType) {
            return this.UNSAFE.contains((Object)rawBaseType.getName());
        }
    }
}

