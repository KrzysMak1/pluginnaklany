/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.TreeSet
 *  java.util.concurrent.ConcurrentHashMap
 */
package dev.gether.getconfig.jackson.databind.jsontype.impl;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import dev.gether.getconfig.jackson.databind.BeanDescription;
import dev.gether.getconfig.jackson.databind.DatabindContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.MapperFeature;
import dev.gether.getconfig.jackson.databind.cfg.MapperConfig;
import dev.gether.getconfig.jackson.databind.jsontype.NamedType;
import dev.gether.getconfig.jackson.databind.jsontype.impl.TypeIdResolverBase;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public class SimpleNameIdResolver
extends TypeIdResolverBase {
    protected final MapperConfig<?> _config;
    protected final ConcurrentHashMap<String, String> _typeToId;
    protected final Map<String, JavaType> _idToType;
    protected final boolean _caseInsensitive;

    protected SimpleNameIdResolver(MapperConfig<?> config, JavaType baseType, ConcurrentHashMap<String, String> typeToId, HashMap<String, JavaType> idToType) {
        super(baseType, config.getTypeFactory());
        this._config = config;
        this._typeToId = typeToId;
        this._idToType = idToType;
        this._caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
    }

    public static SimpleNameIdResolver construct(MapperConfig<?> config, JavaType baseType, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
        HashMap idToType;
        ConcurrentHashMap typeToId;
        if (forSer == forDeser) {
            throw new IllegalArgumentException();
        }
        if (forSer) {
            typeToId = new ConcurrentHashMap();
            idToType = null;
        } else {
            idToType = new HashMap();
            typeToId = new ConcurrentHashMap(4);
        }
        boolean caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
        if (subtypes != null) {
            for (NamedType t : subtypes) {
                JavaType prev;
                String id;
                Class<?> cls = t.getType();
                String string = id = t.hasName() ? t.getName() : SimpleNameIdResolver._defaultTypeId(cls);
                if (forSer) {
                    typeToId.put((Object)cls.getName(), (Object)id);
                }
                if (!forDeser) continue;
                if (caseInsensitive) {
                    id = id.toLowerCase();
                }
                if ((prev = (JavaType)idToType.get((Object)id)) != null && cls.isAssignableFrom(prev.getRawClass())) continue;
                idToType.put((Object)id, (Object)config.constructType(cls));
            }
        }
        return new SimpleNameIdResolver(config, baseType, (ConcurrentHashMap<String, String>)typeToId, (HashMap<String, JavaType>)idToType);
    }

    @Override
    public JsonTypeInfo.Id getMechanism() {
        return JsonTypeInfo.Id.SIMPLE_NAME;
    }

    @Override
    public String idFromValue(Object value) {
        return this.idFromClass(value.getClass());
    }

    protected String idFromClass(Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        String key = clazz.getName();
        String name = (String)this._typeToId.get((Object)key);
        if (name == null) {
            Class<?> cls = this._typeFactory.constructType((Type)clazz).getRawClass();
            if (this._config.isAnnotationProcessingEnabled()) {
                BeanDescription beanDesc = this._config.introspectClassAnnotations(cls);
                name = this._config.getAnnotationIntrospector().findTypeName(beanDesc.getClassInfo());
            }
            if (name == null) {
                name = SimpleNameIdResolver._defaultTypeId(cls);
            }
            this._typeToId.put((Object)key, (Object)name);
        }
        return name;
    }

    @Override
    public String idFromValueAndType(Object value, Class<?> type) {
        if (value == null) {
            return this.idFromClass(type);
        }
        return this.idFromValue(value);
    }

    @Override
    public JavaType typeFromId(DatabindContext context, String id) {
        return this._typeFromId(id);
    }

    protected JavaType _typeFromId(String id) {
        if (this._caseInsensitive) {
            id = id.toLowerCase();
        }
        return (JavaType)this._idToType.get((Object)id);
    }

    @Override
    public String getDescForKnownTypeIds() {
        TreeSet ids = new TreeSet();
        for (Map.Entry entry : this._idToType.entrySet()) {
            if (!((JavaType)entry.getValue()).isConcrete()) continue;
            ids.add(entry.getKey());
        }
        return ids.toString();
    }

    public String toString() {
        return String.format((String)"[%s; id-to-type=%s]", (Object[])new Object[]{this.getClass().getName(), this._idToType});
    }

    protected static String _defaultTypeId(Class<?> cls) {
        String n = cls.getName();
        int ix = Math.max((int)n.lastIndexOf(46), (int)n.lastIndexOf(36));
        return ix < 0 ? n : n.substring(ix + 1);
    }
}

