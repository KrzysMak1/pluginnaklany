/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.util.BitSet
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 */
package dev.gether.getconfig.jackson.databind.jsontype.impl;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.core.JsonToken;
import dev.gether.getconfig.jackson.databind.BeanProperty;
import dev.gether.getconfig.jackson.databind.DeserializationConfig;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.MapperFeature;
import dev.gether.getconfig.jackson.databind.introspect.BeanPropertyDefinition;
import dev.gether.getconfig.jackson.databind.jsontype.NamedType;
import dev.gether.getconfig.jackson.databind.jsontype.TypeDeserializer;
import dev.gether.getconfig.jackson.databind.jsontype.TypeIdResolver;
import dev.gether.getconfig.jackson.databind.jsontype.impl.AsPropertyTypeDeserializer;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;
import dev.gether.getconfig.jackson.databind.util.TokenBuffer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.BitSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class AsDeductionTypeDeserializer
extends AsPropertyTypeDeserializer {
    private static final long serialVersionUID = 1L;
    private static final BitSet EMPTY_CLASS_FINGERPRINT = new BitSet(0);
    private final Map<String, Integer> fieldBitIndex;
    private final Map<BitSet, String> subtypeFingerprints;

    public AsDeductionTypeDeserializer(JavaType bt, TypeIdResolver idRes, JavaType defaultImpl, DeserializationConfig config, Collection<NamedType> subtypes) {
        super(bt, idRes, null, false, defaultImpl, null, true);
        this.fieldBitIndex = new HashMap();
        this.subtypeFingerprints = this.buildFingerprints(config, subtypes);
    }

    public AsDeductionTypeDeserializer(AsDeductionTypeDeserializer src, BeanProperty property) {
        super(src, property);
        this.fieldBitIndex = src.fieldBitIndex;
        this.subtypeFingerprints = src.subtypeFingerprints;
    }

    @Override
    public TypeDeserializer forProperty(BeanProperty prop) {
        return prop == this._property ? this : new AsDeductionTypeDeserializer(this, prop);
    }

    protected Map<BitSet, String> buildFingerprints(DeserializationConfig config, Collection<NamedType> subtypes) {
        boolean ignoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
        int nextField = 0;
        HashMap fingerprints = new HashMap();
        for (NamedType subtype : subtypes) {
            JavaType subtyped = config.getTypeFactory().constructType((Type)subtype.getType());
            List<BeanPropertyDefinition> properties = config.introspect(subtyped).findProperties();
            BitSet fingerprint = new BitSet(nextField + properties.size());
            for (BeanPropertyDefinition property : properties) {
                Integer bitIndex;
                String name = property.getName();
                if (ignoreCase) {
                    name = name.toLowerCase();
                }
                if ((bitIndex = (Integer)this.fieldBitIndex.get((Object)name)) == null) {
                    bitIndex = nextField;
                    this.fieldBitIndex.put((Object)name, (Object)nextField++);
                }
                fingerprint.set(bitIndex.intValue());
            }
            String existingFingerprint = (String)fingerprints.put((Object)fingerprint, (Object)subtype.getType().getName());
            if (existingFingerprint == null) continue;
            throw new IllegalStateException(String.format((String)"Subtypes %s and %s have the same signature and cannot be uniquely deduced.", (Object[])new Object[]{existingFingerprint, subtype.getType().getName()}));
        }
        return fingerprints;
    }

    @Override
    public Object deserializeTypedFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
        String emptySubtype;
        JsonToken t = p.currentToken();
        if (t == JsonToken.START_OBJECT) {
            t = p.nextToken();
        } else if (t != JsonToken.FIELD_NAME) {
            return this._deserializeTypedUsingDefaultImpl(p, ctxt, null, "Unexpected input");
        }
        if (t == JsonToken.END_OBJECT && (emptySubtype = (String)this.subtypeFingerprints.get((Object)EMPTY_CLASS_FINGERPRINT)) != null) {
            return this._deserializeTypedForId(p, ctxt, null, emptySubtype);
        }
        LinkedList candidates = new LinkedList((Collection)this.subtypeFingerprints.keySet());
        TokenBuffer tb = ctxt.bufferForInputBuffering(p);
        boolean ignoreCase = ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
        while (t == JsonToken.FIELD_NAME) {
            String name = p.currentName();
            if (ignoreCase) {
                name = name.toLowerCase();
            }
            tb.copyCurrentStructure(p);
            Integer bit = (Integer)this.fieldBitIndex.get((Object)name);
            if (bit != null) {
                AsDeductionTypeDeserializer.prune((List<BitSet>)candidates, bit);
                if (candidates.size() == 1) {
                    return this._deserializeTypedForId(p, ctxt, tb, (String)this.subtypeFingerprints.get(candidates.get(0)));
                }
            }
            t = p.nextToken();
        }
        String msgToReportIfDefaultImplFailsToo = String.format((String)"Cannot deduce unique subtype of %s (%d candidates match)", (Object[])new Object[]{ClassUtil.getTypeDescription(this._baseType), candidates.size()});
        return this._deserializeTypedUsingDefaultImpl(p, ctxt, tb, msgToReportIfDefaultImplFailsToo);
    }

    private static void prune(List<BitSet> candidates, int bit) {
        Iterator iter = candidates.iterator();
        while (iter.hasNext()) {
            if (((BitSet)iter.next()).get(bit)) continue;
            iter.remove();
        }
    }
}

