/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.jsonFormatVisitors;

import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonAnyFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonBooleanFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWithSerializerProvider;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonMapFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonNullFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonNumberFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;

public interface JsonFormatVisitorWrapper
extends JsonFormatVisitorWithSerializerProvider {
    public JsonObjectFormatVisitor expectObjectFormat(JavaType var1) throws JsonMappingException;

    public JsonArrayFormatVisitor expectArrayFormat(JavaType var1) throws JsonMappingException;

    public JsonStringFormatVisitor expectStringFormat(JavaType var1) throws JsonMappingException;

    public JsonNumberFormatVisitor expectNumberFormat(JavaType var1) throws JsonMappingException;

    public JsonIntegerFormatVisitor expectIntegerFormat(JavaType var1) throws JsonMappingException;

    public JsonBooleanFormatVisitor expectBooleanFormat(JavaType var1) throws JsonMappingException;

    public JsonNullFormatVisitor expectNullFormat(JavaType var1) throws JsonMappingException;

    public JsonAnyFormatVisitor expectAnyFormat(JavaType var1) throws JsonMappingException;

    public JsonMapFormatVisitor expectMapFormat(JavaType var1) throws JsonMappingException;

    public static class Base
    implements JsonFormatVisitorWrapper {
        protected SerializerProvider _provider;

        public Base() {
        }

        public Base(SerializerProvider p) {
            this._provider = p;
        }

        @Override
        public SerializerProvider getProvider() {
            return this._provider;
        }

        @Override
        public void setProvider(SerializerProvider p) {
            this._provider = p;
        }

        @Override
        public JsonObjectFormatVisitor expectObjectFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonArrayFormatVisitor expectArrayFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonStringFormatVisitor expectStringFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonNumberFormatVisitor expectNumberFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonIntegerFormatVisitor expectIntegerFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonBooleanFormatVisitor expectBooleanFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonNullFormatVisitor expectNullFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonAnyFormatVisitor expectAnyFormat(JavaType type) throws JsonMappingException {
            return null;
        }

        @Override
        public JsonMapFormatVisitor expectMapFormat(JavaType type) throws JsonMappingException {
            return null;
        }
    }
}

