/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.introspect;

import dev.gether.getconfig.jackson.databind.EnumNamingStrategy;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;

public class EnumNamingStrategyFactory {
    private EnumNamingStrategyFactory() {
    }

    public static EnumNamingStrategy createEnumNamingStrategyInstance(Object namingDef, boolean canOverrideAccessModifiers) {
        if (namingDef == null) {
            return null;
        }
        if (namingDef instanceof EnumNamingStrategy) {
            return (EnumNamingStrategy)namingDef;
        }
        if (!(namingDef instanceof Class)) {
            throw new IllegalArgumentException(String.format((String)"AnnotationIntrospector returned EnumNamingStrategy definition of type %s; expected type `Class<EnumNamingStrategy>` instead", (Object[])new Object[]{ClassUtil.classNameOf(namingDef)}));
        }
        Class namingClass = (Class)namingDef;
        if (namingClass == EnumNamingStrategy.class) {
            return null;
        }
        if (!EnumNamingStrategy.class.isAssignableFrom(namingClass)) {
            throw new IllegalArgumentException(String.format((String)"Problem with AnnotationIntrospector returned Class %s; expected `Class<EnumNamingStrategy>`", (Object[])new Object[]{ClassUtil.classNameOf(namingClass)}));
        }
        return (EnumNamingStrategy)ClassUtil.createInstance(namingClass, canOverrideAccessModifiers);
    }
}

