/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.deser.impl;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.deser.SettableBeanProperty;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedMember;
import java.io.IOException;

public class MergingSettableBeanProperty
extends SettableBeanProperty.Delegating {
    private static final long serialVersionUID = 1L;
    protected final AnnotatedMember _accessor;

    protected MergingSettableBeanProperty(SettableBeanProperty delegate, AnnotatedMember accessor) {
        super(delegate);
        this._accessor = accessor;
    }

    protected MergingSettableBeanProperty(MergingSettableBeanProperty src, SettableBeanProperty delegate) {
        super(delegate);
        this._accessor = src._accessor;
    }

    public static MergingSettableBeanProperty construct(SettableBeanProperty delegate, AnnotatedMember accessor) {
        return new MergingSettableBeanProperty(delegate, accessor);
    }

    @Override
    protected SettableBeanProperty withDelegate(SettableBeanProperty d) {
        return new MergingSettableBeanProperty(d, this._accessor);
    }

    @Override
    public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
        Object oldValue = this._accessor.getValue(instance);
        Object newValue = oldValue == null ? this.delegate.deserialize(p, ctxt) : this.delegate.deserializeWith(p, ctxt, oldValue);
        if (newValue != oldValue) {
            this.delegate.set(instance, newValue);
        }
    }

    @Override
    public Object deserializeSetAndReturn(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
        Object oldValue = this._accessor.getValue(instance);
        Object newValue = oldValue == null ? this.delegate.deserialize(p, ctxt) : this.delegate.deserializeWith(p, ctxt, oldValue);
        if (newValue != oldValue && newValue != null) {
            return this.delegate.setAndReturn(instance, newValue);
        }
        return instance;
    }

    @Override
    public void set(Object instance, Object value) throws IOException {
        if (value != null) {
            this.delegate.set(instance, value);
        }
    }

    @Override
    public Object setAndReturn(Object instance, Object value) throws IOException {
        if (value != null) {
            return this.delegate.setAndReturn(instance, value);
        }
        return instance;
    }
}

