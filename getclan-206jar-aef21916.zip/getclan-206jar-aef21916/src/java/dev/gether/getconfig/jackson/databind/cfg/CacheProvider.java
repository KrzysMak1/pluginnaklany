/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.cfg;

import dev.gether.getconfig.jackson.databind.DeserializationConfig;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonDeserializer;
import dev.gether.getconfig.jackson.databind.JsonSerializer;
import dev.gether.getconfig.jackson.databind.SerializationConfig;
import dev.gether.getconfig.jackson.databind.util.LookupCache;
import dev.gether.getconfig.jackson.databind.util.TypeKey;
import java.io.Serializable;

public interface CacheProvider
extends Serializable {
    public LookupCache<JavaType, JsonDeserializer<Object>> forDeserializerCache(DeserializationConfig var1);

    public LookupCache<TypeKey, JsonSerializer<Object>> forSerializerCache(SerializationConfig var1);

    public LookupCache<Object, JavaType> forTypeFactory();
}

