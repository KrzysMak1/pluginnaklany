/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.jsonFormatVisitors;

import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonValueFormatVisitor;

public interface JsonBooleanFormatVisitor
extends JsonValueFormatVisitor {

    public static class Base
    extends JsonValueFormatVisitor.Base
    implements JsonBooleanFormatVisitor {
    }
}

