/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 */
package dev.gether.getconfig.jackson.databind.jsontype.impl;

import dev.gether.getconfig.jackson.databind.BeanDescription;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SubTypeValidator {
    protected static final String PREFIX_SPRING = "org.springframework.";
    protected static final String PREFIX_C3P0 = "com.mchange.v2.c3p0.";
    protected static final Set<String> DEFAULT_NO_DESER_CLASS_NAMES;
    protected Set<String> _cfgIllegalClassNames = DEFAULT_NO_DESER_CLASS_NAMES;
    private static final SubTypeValidator instance;

    protected SubTypeValidator() {
    }

    public static SubTypeValidator instance() {
        return instance;
    }

    public void validateSubType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
        String full;
        block6: {
            block7: {
                block8: {
                    Class raw = type.getRawClass();
                    full = raw.getName();
                    if (this._cfgIllegalClassNames.contains((Object)full)) break block6;
                    if (raw.isInterface()) break block7;
                    if (!full.startsWith(PREFIX_SPRING)) break block8;
                    for (Class cls = raw; cls != null && cls != Object.class; cls = cls.getSuperclass()) {
                        String name = cls.getSimpleName();
                        if (!"AbstractPointcutAdvisor".equals((Object)name) && !"AbstractApplicationContext".equals((Object)name)) {
                            continue;
                        }
                        break block6;
                    }
                    break block7;
                }
                if (full.startsWith(PREFIX_C3P0) && full.endsWith("DataSource")) break block6;
            }
            return;
        }
        ctxt.reportBadTypeDefinition(beanDesc, "Illegal type (%s) to deserialize: prevented for security reasons", full);
    }

    static {
        HashSet s = new HashSet();
        s.add((Object)"org.apache.commons.collections.functors.InvokerTransformer");
        s.add((Object)"org.apache.commons.collections.functors.InstantiateTransformer");
        s.add((Object)"org.apache.commons.collections4.functors.InvokerTransformer");
        s.add((Object)"org.apache.commons.collections4.functors.InstantiateTransformer");
        s.add((Object)"org.codehaus.groovy.runtime.ConvertedClosure");
        s.add((Object)"org.codehaus.groovy.runtime.MethodClosure");
        s.add((Object)"org.springframework.beans.factory.ObjectFactory");
        s.add((Object)"com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl");
        s.add((Object)"org.apache.xalan.xsltc.trax.TemplatesImpl");
        s.add((Object)"com.sun.rowset.JdbcRowSetImpl");
        s.add((Object)"java.util.logging.FileHandler");
        s.add((Object)"java.rmi.server.UnicastRemoteObject");
        s.add((Object)"org.springframework.beans.factory.config.PropertyPathFactoryBean");
        s.add((Object)"org.springframework.aop.config.MethodLocatingFactoryBean");
        s.add((Object)"org.springframework.beans.factory.config.BeanReferenceFactoryBean");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp2.BasicDataSource");
        s.add((Object)"com.sun.org.apache.bcel.internal.util.ClassLoader");
        s.add((Object)"org.hibernate.jmx.StatisticsService");
        s.add((Object)"org.apache.ibatis.datasource.jndi.JndiDataSourceFactory");
        s.add((Object)"org.apache.ibatis.parsing.XPathParser");
        s.add((Object)"jodd.db.connection.DataSourceConnectionProvider");
        s.add((Object)"oracle.jdbc.connector.OracleManagedConnectionFactory");
        s.add((Object)"oracle.jdbc.rowset.OracleJDBCRowSet");
        s.add((Object)"org.slf4j.ext.EventData");
        s.add((Object)"flex.messaging.util.concurrent.AsynchBeansWorkManagerExecutor");
        s.add((Object)"com.sun.deploy.security.ruleset.DRSHelper");
        s.add((Object)"org.apache.axis2.jaxws.spi.handler.HandlerResolverImpl");
        s.add((Object)"org.jboss.util.propertyeditor.DocumentEditor");
        s.add((Object)"org.apache.openjpa.ee.RegistryManagedRuntime");
        s.add((Object)"org.apache.openjpa.ee.JNDIManagedRuntime");
        s.add((Object)"org.apache.openjpa.ee.WASRegistryManagedRuntime");
        s.add((Object)"org.apache.axis2.transport.jms.JMSOutTransportInfo");
        s.add((Object)"com.mysql.cj.jdbc.admin.MiniAdmin");
        s.add((Object)"ch.qos.logback.core.db.DriverManagerConnectionSource");
        s.add((Object)"org.jdom.transform.XSLTransformer");
        s.add((Object)"org.jdom2.transform.XSLTransformer");
        s.add((Object)"net.sf.ehcache.transaction.manager.DefaultTransactionManagerLookup");
        s.add((Object)"net.sf.ehcache.hibernate.EhcacheJtaTransactionManagerLookup");
        s.add((Object)"ch.qos.logback.core.db.JNDIConnectionSource");
        s.add((Object)"com.zaxxer.hikari.HikariConfig");
        s.add((Object)"com.zaxxer.hikari.HikariDataSource");
        s.add((Object)"org.apache.cxf.jaxrs.provider.XSLTJaxbProvider");
        s.add((Object)"org.apache.commons.configuration.JNDIConfiguration");
        s.add((Object)"org.apache.commons.configuration2.JNDIConfiguration");
        s.add((Object)"org.apache.xalan.lib.sql.JNDIConnectionPool");
        s.add((Object)"com.sun.org.apache.xalan.internal.lib.sql.JNDIConnectionPool");
        s.add((Object)"org.apache.commons.dbcp.cpdsadapter.DriverAdapterCPDS");
        s.add((Object)"org.apache.commons.dbcp.datasources.PerUserPoolDataSource");
        s.add((Object)"org.apache.commons.dbcp.datasources.SharedPoolDataSource");
        s.add((Object)"com.p6spy.engine.spy.P6DataSource");
        s.add((Object)"org.apache.log4j.receivers.db.DriverManagerConnectionSource");
        s.add((Object)"org.apache.log4j.receivers.db.JNDIConnectionSource");
        s.add((Object)"net.sf.ehcache.transaction.manager.selector.GenericJndiSelector");
        s.add((Object)"net.sf.ehcache.transaction.manager.selector.GlassfishSelector");
        s.add((Object)"org.apache.xbean.propertyeditor.JndiConverter");
        s.add((Object)"org.apache.hadoop.shaded.com.zaxxer.hikari.HikariConfig");
        s.add((Object)"com.ibatis.sqlmap.engine.transaction.jta.JtaTransactionConfig");
        s.add((Object)"br.com.anteros.dbcp.AnterosDBCPConfig");
        s.add((Object)"br.com.anteros.dbcp.AnterosDBCPDataSource");
        s.add((Object)"javax.swing.JEditorPane");
        s.add((Object)"javax.swing.JTextPane");
        s.add((Object)"org.apache.shiro.realm.jndi.JndiRealmFactory");
        s.add((Object)"org.apache.shiro.jndi.JndiObjectFactory");
        s.add((Object)"org.apache.ignite.cache.jta.jndi.CacheJndiTmLookup");
        s.add((Object)"org.apache.ignite.cache.jta.jndi.CacheJndiTmFactory");
        s.add((Object)"org.quartz.utils.JNDIConnectionProvider");
        s.add((Object)"org.apache.aries.transaction.jms.internal.XaPooledConnectionFactory");
        s.add((Object)"org.apache.aries.transaction.jms.RecoverablePooledConnectionFactory");
        s.add((Object)"com.caucho.config.types.ResourceRef");
        s.add((Object)"org.aoju.bus.proxy.provider.RmiProvider");
        s.add((Object)"org.aoju.bus.proxy.provider.remoting.RmiProvider");
        s.add((Object)"org.apache.activemq.ActiveMQConnectionFactory");
        s.add((Object)"org.apache.activemq.ActiveMQXAConnectionFactory");
        s.add((Object)"org.apache.activemq.spring.ActiveMQConnectionFactory");
        s.add((Object)"org.apache.activemq.spring.ActiveMQXAConnectionFactory");
        s.add((Object)"org.apache.activemq.pool.JcaPooledConnectionFactory");
        s.add((Object)"org.apache.activemq.pool.PooledConnectionFactory");
        s.add((Object)"org.apache.activemq.pool.XaPooledConnectionFactory");
        s.add((Object)"org.apache.activemq.jms.pool.XaPooledConnectionFactory");
        s.add((Object)"org.apache.activemq.jms.pool.JcaPooledConnectionFactory");
        s.add((Object)"org.apache.commons.proxy.provider.remoting.RmiProvider");
        s.add((Object)"org.apache.commons.jelly.impl.Embedded");
        s.add((Object)"oadd.org.apache.xalan.lib.sql.JNDIConnectionPool");
        s.add((Object)"oadd.org.apache.commons.dbcp.cpdsadapter.DriverAdapterCPDS");
        s.add((Object)"oadd.org.apache.commons.dbcp.datasources.PerUserPoolDataSource");
        s.add((Object)"oadd.org.apache.commons.dbcp.datasources.SharedPoolDataSource");
        s.add((Object)"oracle.jms.AQjmsQueueConnectionFactory");
        s.add((Object)"oracle.jms.AQjmsXATopicConnectionFactory");
        s.add((Object)"oracle.jms.AQjmsTopicConnectionFactory");
        s.add((Object)"oracle.jms.AQjmsXAQueueConnectionFactory");
        s.add((Object)"oracle.jms.AQjmsXAConnectionFactory");
        s.add((Object)"org.jsecurity.realm.jndi.JndiRealmFactory");
        s.add((Object)"com.pastdev.httpcomponents.configuration.JndiConfiguration");
        s.add((Object)"com.nqadmin.rowset.JdbcRowSetImpl");
        s.add((Object)"org.arrah.framework.rdbms.UpdatableJdbcRowsetImpl");
        s.add((Object)"org.apache.commons.dbcp2.datasources.PerUserPoolDataSource");
        s.add((Object)"org.apache.commons.dbcp2.datasources.SharedPoolDataSource");
        s.add((Object)"org.apache.commons.dbcp2.cpdsadapter.DriverAdapterCPDS");
        s.add((Object)"com.newrelic.agent.deps.ch.qos.logback.core.db.JNDIConnectionSource");
        s.add((Object)"com.newrelic.agent.deps.ch.qos.logback.core.db.DriverManagerConnectionSource");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp.cpdsadapter.DriverAdapterCPDS");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp.datasources.PerUserPoolDataSource");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp.datasources.SharedPoolDataSource");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp2.cpdsadapter.DriverAdapterCPDS");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp2.datasources.PerUserPoolDataSource");
        s.add((Object)"org.apache.tomcat.dbcp.dbcp2.datasources.SharedPoolDataSource");
        s.add((Object)"com.oracle.wls.shaded.org.apache.xalan.lib.sql.JNDIConnectionPool");
        s.add((Object)"org.docx4j.org.apache.xalan.lib.sql.JNDIConnectionPool");
        DEFAULT_NO_DESER_CLASS_NAMES = Collections.unmodifiableSet((Set)s);
        instance = new SubTypeValidator();
    }
}

