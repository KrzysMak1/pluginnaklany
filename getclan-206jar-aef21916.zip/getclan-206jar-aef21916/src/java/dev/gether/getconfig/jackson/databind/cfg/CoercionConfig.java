/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.util.Arrays
 */
package dev.gether.getconfig.jackson.databind.cfg;

import dev.gether.getconfig.jackson.databind.cfg.CoercionAction;
import dev.gether.getconfig.jackson.databind.cfg.CoercionInputShape;
import java.io.Serializable;
import java.util.Arrays;

public class CoercionConfig
implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final int INPUT_SHAPE_COUNT = CoercionInputShape.values().length;
    protected Boolean _acceptBlankAsEmpty;
    protected final CoercionAction[] _coercionsByShape;

    public CoercionConfig() {
        this._coercionsByShape = new CoercionAction[INPUT_SHAPE_COUNT];
        this._acceptBlankAsEmpty = null;
    }

    protected CoercionConfig(CoercionConfig src) {
        this._acceptBlankAsEmpty = src._acceptBlankAsEmpty;
        this._coercionsByShape = (CoercionAction[])Arrays.copyOf((Object[])src._coercionsByShape, (int)src._coercionsByShape.length);
    }

    public CoercionAction findAction(CoercionInputShape shape) {
        return this._coercionsByShape[shape.ordinal()];
    }

    public Boolean getAcceptBlankAsEmpty() {
        return this._acceptBlankAsEmpty;
    }
}

