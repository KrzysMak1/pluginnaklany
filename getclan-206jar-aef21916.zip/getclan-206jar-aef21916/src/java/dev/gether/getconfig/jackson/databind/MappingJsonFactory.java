/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind;

import dev.gether.getconfig.jackson.core.JsonFactory;
import dev.gether.getconfig.jackson.core.format.InputAccessor;
import dev.gether.getconfig.jackson.core.format.MatchStrength;
import dev.gether.getconfig.jackson.databind.ObjectMapper;
import java.io.IOException;

public class MappingJsonFactory
extends JsonFactory {
    private static final long serialVersionUID = -1L;

    public MappingJsonFactory() {
        this((ObjectMapper)null);
    }

    public MappingJsonFactory(ObjectMapper mapper) {
        super(mapper);
        if (mapper == null) {
            this.setCodec(new ObjectMapper(this));
        }
    }

    public MappingJsonFactory(JsonFactory src, ObjectMapper mapper) {
        super(src, mapper);
        if (mapper == null) {
            this.setCodec(new ObjectMapper(this));
        }
    }

    @Override
    public final ObjectMapper getCodec() {
        return (ObjectMapper)this._objectCodec;
    }

    @Override
    public JsonFactory copy() {
        this._checkInvalidCopy(MappingJsonFactory.class);
        return new MappingJsonFactory((JsonFactory)this, null);
    }

    @Override
    public String getFormatName() {
        return "JSON";
    }

    @Override
    public MatchStrength hasFormat(InputAccessor acc) throws IOException {
        if (this.getClass() == MappingJsonFactory.class) {
            return this.hasJSONFormat(acc);
        }
        return null;
    }
}

