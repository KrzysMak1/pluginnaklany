/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.HashMap
 */
package dev.gether.getconfig.jackson.databind.module;

import dev.gether.getconfig.jackson.databind.BeanDescription;
import dev.gether.getconfig.jackson.databind.DeserializationConfig;
import dev.gether.getconfig.jackson.databind.deser.ValueInstantiator;
import dev.gether.getconfig.jackson.databind.deser.ValueInstantiators;
import dev.gether.getconfig.jackson.databind.type.ClassKey;
import java.io.Serializable;
import java.util.HashMap;

public class SimpleValueInstantiators
extends ValueInstantiators.Base
implements Serializable {
    private static final long serialVersionUID = -8929386427526115130L;
    protected HashMap<ClassKey, ValueInstantiator> _classMappings = new HashMap();

    public SimpleValueInstantiators addValueInstantiator(Class<?> forType, ValueInstantiator inst) {
        this._classMappings.put((Object)new ClassKey(forType), (Object)inst);
        return this;
    }

    @Override
    public ValueInstantiator findValueInstantiator(DeserializationConfig config, BeanDescription beanDesc, ValueInstantiator defaultInstantiator) {
        ValueInstantiator inst = (ValueInstantiator)this._classMappings.get((Object)new ClassKey(beanDesc.getBeanClass()));
        return inst == null ? defaultInstantiator : inst;
    }
}

