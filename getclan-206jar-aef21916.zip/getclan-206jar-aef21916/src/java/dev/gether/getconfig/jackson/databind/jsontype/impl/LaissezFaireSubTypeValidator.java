/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.jsontype.impl;

import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.cfg.MapperConfig;
import dev.gether.getconfig.jackson.databind.jsontype.PolymorphicTypeValidator;

public final class LaissezFaireSubTypeValidator
extends PolymorphicTypeValidator.Base {
    private static final long serialVersionUID = 1L;
    public static final LaissezFaireSubTypeValidator instance = new LaissezFaireSubTypeValidator();

    @Override
    public PolymorphicTypeValidator.Validity validateBaseType(MapperConfig<?> ctxt, JavaType baseType) {
        return PolymorphicTypeValidator.Validity.INDETERMINATE;
    }

    @Override
    public PolymorphicTypeValidator.Validity validateSubClassName(MapperConfig<?> ctxt, JavaType baseType, String subClassName) {
        return PolymorphicTypeValidator.Validity.ALLOWED;
    }

    @Override
    public PolymorphicTypeValidator.Validity validateSubType(MapperConfig<?> ctxt, JavaType baseType, JavaType subType) {
        return PolymorphicTypeValidator.Validity.ALLOWED;
    }
}

