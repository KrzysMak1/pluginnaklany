/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Byte
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Short
 *  java.lang.String
 *  java.math.BigDecimal
 *  java.math.BigInteger
 */
package dev.gether.getconfig.jackson.databind.node;

import dev.gether.getconfig.jackson.databind.JsonNode;
import dev.gether.getconfig.jackson.databind.node.ArrayNode;
import dev.gether.getconfig.jackson.databind.node.BigIntegerNode;
import dev.gether.getconfig.jackson.databind.node.BinaryNode;
import dev.gether.getconfig.jackson.databind.node.BooleanNode;
import dev.gether.getconfig.jackson.databind.node.DecimalNode;
import dev.gether.getconfig.jackson.databind.node.DoubleNode;
import dev.gether.getconfig.jackson.databind.node.FloatNode;
import dev.gether.getconfig.jackson.databind.node.IntNode;
import dev.gether.getconfig.jackson.databind.node.JsonNodeCreator;
import dev.gether.getconfig.jackson.databind.node.LongNode;
import dev.gether.getconfig.jackson.databind.node.MissingNode;
import dev.gether.getconfig.jackson.databind.node.NullNode;
import dev.gether.getconfig.jackson.databind.node.NumericNode;
import dev.gether.getconfig.jackson.databind.node.ObjectNode;
import dev.gether.getconfig.jackson.databind.node.POJONode;
import dev.gether.getconfig.jackson.databind.node.ShortNode;
import dev.gether.getconfig.jackson.databind.node.TextNode;
import dev.gether.getconfig.jackson.databind.node.ValueNode;
import dev.gether.getconfig.jackson.databind.util.RawValue;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public class JsonNodeFactory
implements Serializable,
JsonNodeCreator {
    private static final long serialVersionUID = 1L;
    protected static final int MAX_ELEMENT_INDEX_FOR_INSERT = 9999;
    @Deprecated
    private final boolean _cfgBigDecimalExact;
    public static final JsonNodeFactory instance = new JsonNodeFactory();

    public JsonNodeFactory(boolean bigDecimalExact) {
        this._cfgBigDecimalExact = bigDecimalExact;
    }

    protected JsonNodeFactory() {
        this(false);
    }

    @Deprecated
    public static JsonNodeFactory withExactBigDecimals(boolean bigDecimalExact) {
        return new JsonNodeFactory(bigDecimalExact);
    }

    public int getMaxElementIndexForInsert() {
        return 9999;
    }

    public boolean willStripTrailingBigDecimalZeroes() {
        return !this._cfgBigDecimalExact;
    }

    @Override
    public BooleanNode booleanNode(boolean v) {
        return v ? BooleanNode.getTrue() : BooleanNode.getFalse();
    }

    @Override
    public NullNode nullNode() {
        return NullNode.getInstance();
    }

    public JsonNode missingNode() {
        return MissingNode.getInstance();
    }

    @Override
    public NumericNode numberNode(byte v) {
        return IntNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Byte value) {
        return value == null ? this.nullNode() : IntNode.valueOf(value.intValue());
    }

    @Override
    public NumericNode numberNode(short v) {
        return ShortNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Short value) {
        return value == null ? this.nullNode() : ShortNode.valueOf(value);
    }

    @Override
    public NumericNode numberNode(int v) {
        return IntNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Integer value) {
        return value == null ? this.nullNode() : IntNode.valueOf(value);
    }

    @Override
    public NumericNode numberNode(long v) {
        return LongNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Long v) {
        if (v == null) {
            return this.nullNode();
        }
        return LongNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(BigInteger v) {
        if (v == null) {
            return this.nullNode();
        }
        return BigIntegerNode.valueOf(v);
    }

    @Override
    public NumericNode numberNode(float v) {
        return FloatNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Float value) {
        return value == null ? this.nullNode() : FloatNode.valueOf(value.floatValue());
    }

    @Override
    public NumericNode numberNode(double v) {
        return DoubleNode.valueOf(v);
    }

    @Override
    public ValueNode numberNode(Double value) {
        return value == null ? this.nullNode() : DoubleNode.valueOf(value);
    }

    @Override
    public ValueNode numberNode(BigDecimal v) {
        if (v == null) {
            return this.nullNode();
        }
        return DecimalNode.valueOf(v);
    }

    @Override
    public TextNode textNode(String text) {
        return TextNode.valueOf(text);
    }

    @Override
    public BinaryNode binaryNode(byte[] data) {
        return BinaryNode.valueOf(data);
    }

    @Override
    public BinaryNode binaryNode(byte[] data, int offset, int length) {
        return BinaryNode.valueOf(data, offset, length);
    }

    @Override
    public ArrayNode arrayNode() {
        return new ArrayNode(this);
    }

    @Override
    public ArrayNode arrayNode(int capacity) {
        return new ArrayNode(this, capacity);
    }

    @Override
    public ObjectNode objectNode() {
        return new ObjectNode(this);
    }

    @Override
    public ValueNode pojoNode(Object pojo) {
        return new POJONode(pojo);
    }

    @Override
    public ValueNode rawValueNode(RawValue value) {
        return new POJONode(value);
    }

    protected boolean _inIntRange(long l) {
        int i = (int)l;
        long l2 = i;
        return l2 == l;
    }
}

