/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.jsontype;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import dev.gether.getconfig.jackson.databind.DatabindContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import java.io.IOException;

public interface TypeIdResolver {
    public void init(JavaType var1);

    public String idFromValue(Object var1);

    public String idFromValueAndType(Object var1, Class<?> var2);

    public String idFromBaseType();

    public JavaType typeFromId(DatabindContext var1, String var2) throws IOException;

    public String getDescForKnownTypeIds();

    public JsonTypeInfo.Id getMechanism();
}

