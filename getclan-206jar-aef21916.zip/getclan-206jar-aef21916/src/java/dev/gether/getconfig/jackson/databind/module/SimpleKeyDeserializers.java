/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.HashMap
 */
package dev.gether.getconfig.jackson.databind.module;

import dev.gether.getconfig.jackson.databind.BeanDescription;
import dev.gether.getconfig.jackson.databind.DeserializationConfig;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.KeyDeserializer;
import dev.gether.getconfig.jackson.databind.deser.KeyDeserializers;
import dev.gether.getconfig.jackson.databind.type.ClassKey;
import java.io.Serializable;
import java.util.HashMap;

public class SimpleKeyDeserializers
implements KeyDeserializers,
Serializable {
    private static final long serialVersionUID = 1L;
    protected HashMap<ClassKey, KeyDeserializer> _classMappings = null;

    public SimpleKeyDeserializers addDeserializer(Class<?> forClass, KeyDeserializer deser) {
        if (this._classMappings == null) {
            this._classMappings = new HashMap();
        }
        this._classMappings.put((Object)new ClassKey(forClass), (Object)deser);
        return this;
    }

    @Override
    public KeyDeserializer findKeyDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc) {
        if (this._classMappings == null) {
            return null;
        }
        return (KeyDeserializer)this._classMappings.get((Object)new ClassKey(type.getRawClass()));
    }
}

