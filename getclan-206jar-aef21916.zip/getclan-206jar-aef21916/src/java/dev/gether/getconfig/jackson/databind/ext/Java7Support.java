/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalAccessError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package dev.gether.getconfig.jackson.databind.ext;

import dev.gether.getconfig.jackson.databind.PropertyName;
import dev.gether.getconfig.jackson.databind.introspect.Annotated;
import dev.gether.getconfig.jackson.databind.introspect.AnnotatedParameter;
import dev.gether.getconfig.jackson.databind.util.ClassUtil;
import dev.gether.getconfig.jackson.databind.util.ExceptionUtil;

public abstract class Java7Support {
    private static final Java7Support IMPL;

    public static Java7Support instance() {
        return IMPL;
    }

    public abstract Boolean findTransient(Annotated var1);

    public abstract Boolean hasCreatorAnnotation(Annotated var1);

    public abstract PropertyName findConstructorName(AnnotatedParameter var1);

    static {
        Java7Support impl = null;
        try {
            Class cls = Class.forName((String)"dev.gether.getconfig.jackson.databind.ext.Java7SupportImpl");
            impl = (Java7Support)ClassUtil.createInstance(cls, false);
        }
        catch (IllegalAccessError cls) {
        }
        catch (Throwable t) {
            ExceptionUtil.rethrowIfFatal(t);
        }
        IMPL = impl;
    }
}

