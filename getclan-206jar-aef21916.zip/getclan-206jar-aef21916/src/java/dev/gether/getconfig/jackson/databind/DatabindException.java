/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package dev.gether.getconfig.jackson.databind;

import dev.gether.getconfig.jackson.core.JsonLocation;
import dev.gether.getconfig.jackson.core.JsonProcessingException;

public abstract class DatabindException
extends JsonProcessingException {
    private static final long serialVersionUID = 3L;

    protected DatabindException(String msg, JsonLocation loc, Throwable rootCause) {
        super(msg, loc, rootCause);
    }

    protected DatabindException(String msg) {
        super(msg);
    }

    protected DatabindException(String msg, JsonLocation loc) {
        this(msg, loc, null);
    }

    protected DatabindException(String msg, Throwable rootCause) {
        this(msg, null, rootCause);
    }

    public abstract void prependPath(Object var1, String var2);

    public abstract void prependPath(Object var1, int var2);
}

