/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.ser.impl;

import dev.gether.getconfig.jackson.core.JsonGenerator;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.ser.std.StdSerializer;
import java.io.IOException;

public class FailingSerializer
extends StdSerializer<Object> {
    protected final String _msg;

    public FailingSerializer(String msg) {
        super(Object.class);
        this._msg = msg;
    }

    @Override
    public void serialize(Object value, JsonGenerator g, SerializerProvider ctxt) throws IOException {
        ctxt.reportMappingProblem(this._msg, new Object[0]);
    }
}

