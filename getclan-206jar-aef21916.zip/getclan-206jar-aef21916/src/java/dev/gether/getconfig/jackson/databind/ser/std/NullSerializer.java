/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.reflect.Type
 */
package dev.gether.getconfig.jackson.databind.ser.std;

import dev.gether.getconfig.jackson.core.JsonGenerator;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.JsonNode;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.annotation.JacksonStdImpl;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import dev.gether.getconfig.jackson.databind.jsontype.TypeSerializer;
import dev.gether.getconfig.jackson.databind.ser.std.StdSerializer;
import java.io.IOException;
import java.lang.reflect.Type;

@JacksonStdImpl
public class NullSerializer
extends StdSerializer<Object> {
    public static final NullSerializer instance = new NullSerializer();

    private NullSerializer() {
        super(Object.class);
    }

    @Override
    public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeNull();
    }

    @Override
    public void serializeWithType(Object value, JsonGenerator gen, SerializerProvider serializers, TypeSerializer typeSer) throws IOException {
        gen.writeNull();
    }

    @Override
    @Deprecated
    public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException {
        return this.createSchemaNode("null");
    }

    @Override
    public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
        visitor.expectNullFormat(typeHint);
    }
}

