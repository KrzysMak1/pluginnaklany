/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.ser;

import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.JsonSerializer;
import dev.gether.getconfig.jackson.databind.SerializationConfig;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.jsontype.TypeSerializer;
import dev.gether.getconfig.jackson.databind.ser.BeanSerializerModifier;
import dev.gether.getconfig.jackson.databind.ser.Serializers;

public abstract class SerializerFactory {
    public abstract SerializerFactory withAdditionalSerializers(Serializers var1);

    public abstract SerializerFactory withAdditionalKeySerializers(Serializers var1);

    public abstract SerializerFactory withSerializerModifier(BeanSerializerModifier var1);

    public abstract JsonSerializer<Object> createSerializer(SerializerProvider var1, JavaType var2) throws JsonMappingException;

    public abstract TypeSerializer createTypeSerializer(SerializationConfig var1, JavaType var2) throws JsonMappingException;

    public JsonSerializer<Object> createKeySerializer(SerializerProvider prov, JavaType type, JsonSerializer<Object> defaultImpl) throws JsonMappingException {
        return this.createKeySerializer(prov.getConfig(), type, defaultImpl);
    }

    @Deprecated
    public abstract JsonSerializer<Object> createKeySerializer(SerializationConfig var1, JavaType var2, JsonSerializer<Object> var3) throws JsonMappingException;
}

