/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind.exc;

import dev.gether.getconfig.jackson.core.JsonLocation;
import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.exc.MismatchedInputException;

public class InvalidFormatException
extends MismatchedInputException {
    private static final long serialVersionUID = 1L;
    protected final Object _value;

    @Deprecated
    public InvalidFormatException(String msg, Object value, Class<?> targetType) {
        super((JsonParser)null, msg);
        this._value = value;
        this._targetType = targetType;
    }

    @Deprecated
    public InvalidFormatException(String msg, JsonLocation loc, Object value, Class<?> targetType) {
        super((JsonParser)null, msg, loc);
        this._value = value;
        this._targetType = targetType;
    }

    public InvalidFormatException(JsonParser p, String msg, Object value, Class<?> targetType) {
        super(p, msg, targetType);
        this._value = value;
    }

    public static InvalidFormatException from(JsonParser p, String msg, Object value, Class<?> targetType) {
        return new InvalidFormatException(p, msg, value, targetType);
    }

    public Object getValue() {
        return this._value;
    }
}

