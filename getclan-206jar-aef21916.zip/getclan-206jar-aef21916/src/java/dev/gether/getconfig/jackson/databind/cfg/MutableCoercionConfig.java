/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.cfg;

import dev.gether.getconfig.jackson.databind.cfg.CoercionAction;
import dev.gether.getconfig.jackson.databind.cfg.CoercionConfig;
import dev.gether.getconfig.jackson.databind.cfg.CoercionInputShape;
import java.io.Serializable;

public class MutableCoercionConfig
extends CoercionConfig
implements Serializable {
    private static final long serialVersionUID = 1L;

    public MutableCoercionConfig() {
    }

    protected MutableCoercionConfig(MutableCoercionConfig src) {
        super(src);
    }

    public MutableCoercionConfig copy() {
        return new MutableCoercionConfig(this);
    }

    public MutableCoercionConfig setCoercion(CoercionInputShape shape, CoercionAction action) {
        this._coercionsByShape[shape.ordinal()] = action;
        return this;
    }

    public MutableCoercionConfig setAcceptBlankAsEmpty(Boolean state) {
        this._acceptBlankAsEmpty = state;
        return this;
    }
}

