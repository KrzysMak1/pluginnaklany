/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Override
 */
package dev.gether.getconfig.jackson.databind.deser.std;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonDeserializer;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.JsonNode;
import dev.gether.getconfig.jackson.databind.deser.ResolvableDeserializer;
import dev.gether.getconfig.jackson.databind.deser.std.StdDeserializer;
import dev.gether.getconfig.jackson.databind.jsontype.TypeDeserializer;
import java.io.IOException;

public abstract class StdNodeBasedDeserializer<T>
extends StdDeserializer<T>
implements ResolvableDeserializer {
    private static final long serialVersionUID = 1L;
    protected JsonDeserializer<Object> _treeDeserializer;

    protected StdNodeBasedDeserializer(JavaType targetType) {
        super(targetType);
    }

    protected StdNodeBasedDeserializer(Class<T> targetType) {
        super(targetType);
    }

    protected StdNodeBasedDeserializer(StdNodeBasedDeserializer<?> src) {
        super(src);
        this._treeDeserializer = src._treeDeserializer;
    }

    @Override
    public void resolve(DeserializationContext ctxt) throws JsonMappingException {
        this._treeDeserializer = ctxt.findRootValueDeserializer(ctxt.constructType(JsonNode.class));
    }

    public abstract T convert(JsonNode var1, DeserializationContext var2) throws IOException;

    public T convert(JsonNode root, DeserializationContext ctxt, T newValue) throws IOException {
        ctxt.handleBadMerge(this);
        return this.convert(root, ctxt);
    }

    @Override
    public T deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        JsonNode n = (JsonNode)this._treeDeserializer.deserialize(jp, ctxt);
        return this.convert(n, ctxt);
    }

    @Override
    public T deserialize(JsonParser jp, DeserializationContext ctxt, T newValue) throws IOException {
        JsonNode n = (JsonNode)this._treeDeserializer.deserialize(jp, ctxt);
        return this.convert(n, ctxt, newValue);
    }

    @Override
    public Object deserializeWithType(JsonParser jp, DeserializationContext ctxt, TypeDeserializer td) throws IOException {
        JsonNode n = (JsonNode)this._treeDeserializer.deserializeWithType(jp, ctxt, td);
        return this.convert(n, ctxt);
    }
}

