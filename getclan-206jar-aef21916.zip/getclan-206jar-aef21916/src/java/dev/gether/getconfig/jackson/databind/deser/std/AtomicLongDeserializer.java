/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.concurrent.atomic.AtomicLong
 */
package dev.gether.getconfig.jackson.databind.deser.std;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.DeserializationContext;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.deser.std.StdScalarDeserializer;
import dev.gether.getconfig.jackson.databind.type.LogicalType;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

public class AtomicLongDeserializer
extends StdScalarDeserializer<AtomicLong> {
    private static final long serialVersionUID = 1L;

    public AtomicLongDeserializer() {
        super(AtomicLong.class);
    }

    @Override
    public AtomicLong deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        if (p.isExpectedNumberIntToken()) {
            return new AtomicLong(p.getLongValue());
        }
        Long L = this._parseLong(p, ctxt, AtomicLong.class);
        return L == null ? null : new AtomicLong((long)L.intValue());
    }

    @Override
    public LogicalType logicalType() {
        return LogicalType.Integer;
    }

    @Override
    public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
        return new AtomicLong();
    }
}

