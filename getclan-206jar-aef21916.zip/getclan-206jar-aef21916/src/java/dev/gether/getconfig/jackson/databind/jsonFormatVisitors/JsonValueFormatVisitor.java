/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Set
 */
package dev.gether.getconfig.jackson.databind.jsonFormatVisitors;

import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonValueFormat;
import java.util.Set;

public interface JsonValueFormatVisitor {
    public void format(JsonValueFormat var1);

    public void enumTypes(Set<String> var1);

    public static class Base
    implements JsonValueFormatVisitor {
        @Override
        public void format(JsonValueFormat format) {
        }

        @Override
        public void enumTypes(Set<String> enums) {
        }
    }
}

