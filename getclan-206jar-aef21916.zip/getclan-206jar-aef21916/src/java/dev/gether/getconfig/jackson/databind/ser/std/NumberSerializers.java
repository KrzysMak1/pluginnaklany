/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Byte
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.math.BigDecimal
 *  java.util.Map
 */
package dev.gether.getconfig.jackson.databind.ser.std;

import com.fasterxml.jackson.annotation.JsonFormat;
import dev.gether.getconfig.jackson.core.JsonGenerator;
import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.core.JsonToken;
import dev.gether.getconfig.jackson.core.io.NumberOutput;
import dev.gether.getconfig.jackson.core.type.WritableTypeId;
import dev.gether.getconfig.jackson.databind.BeanProperty;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import dev.gether.getconfig.jackson.databind.JsonNode;
import dev.gether.getconfig.jackson.databind.JsonSerializer;
import dev.gether.getconfig.jackson.databind.SerializerProvider;
import dev.gether.getconfig.jackson.databind.annotation.JacksonStdImpl;
import dev.gether.getconfig.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
import dev.gether.getconfig.jackson.databind.jsontype.TypeSerializer;
import dev.gether.getconfig.jackson.databind.ser.ContextualSerializer;
import dev.gether.getconfig.jackson.databind.ser.std.NumberSerializer;
import dev.gether.getconfig.jackson.databind.ser.std.StdScalarSerializer;
import dev.gether.getconfig.jackson.databind.ser.std.ToStringSerializer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.Map;

public class NumberSerializers {
    protected NumberSerializers() {
    }

    public static void addAll(Map<String, JsonSerializer<?>> allDeserializers) {
        allDeserializers.put((Object)Integer.class.getName(), (Object)new IntegerSerializer(Integer.class));
        allDeserializers.put((Object)Integer.TYPE.getName(), (Object)new IntegerSerializer((Class<?>)Integer.TYPE));
        allDeserializers.put((Object)Long.class.getName(), (Object)new LongSerializer(Long.class));
        allDeserializers.put((Object)Long.TYPE.getName(), (Object)new LongSerializer((Class<?>)Long.TYPE));
        allDeserializers.put((Object)Byte.class.getName(), (Object)IntLikeSerializer.instance);
        allDeserializers.put((Object)Byte.TYPE.getName(), (Object)IntLikeSerializer.instance);
        allDeserializers.put((Object)Short.class.getName(), (Object)ShortSerializer.instance);
        allDeserializers.put((Object)Short.TYPE.getName(), (Object)ShortSerializer.instance);
        allDeserializers.put((Object)Double.class.getName(), (Object)new DoubleSerializer(Double.class));
        allDeserializers.put((Object)Double.TYPE.getName(), (Object)new DoubleSerializer((Class<?>)Double.TYPE));
        allDeserializers.put((Object)Float.class.getName(), (Object)FloatSerializer.instance);
        allDeserializers.put((Object)Float.TYPE.getName(), (Object)FloatSerializer.instance);
    }

    @JacksonStdImpl
    public static class DoubleSerializer
    extends Base<Object> {
        public DoubleSerializer(Class<?> cls) {
            super(cls, JsonParser.NumberType.DOUBLE, "number");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber((Double)value);
        }

        @Override
        public void serializeWithType(Object value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
            Double d = (Double)value;
            if (NumberOutput.notFinite(d)) {
                WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer.typeId(value, JsonToken.VALUE_NUMBER_FLOAT));
                g.writeNumber(d);
                typeSer.writeTypeSuffix(g, typeIdDef);
            } else {
                g.writeNumber(d);
            }
        }

        @Deprecated
        public static boolean notFinite(double value) {
            return NumberOutput.notFinite(value);
        }
    }

    @JacksonStdImpl
    public static class FloatSerializer
    extends Base<Object> {
        static final FloatSerializer instance = new FloatSerializer();

        public FloatSerializer() {
            super(Float.class, JsonParser.NumberType.FLOAT, "number");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber(((Float)value).floatValue());
        }
    }

    @JacksonStdImpl
    public static class LongSerializer
    extends Base<Object> {
        public LongSerializer(Class<?> cls) {
            super(cls, JsonParser.NumberType.LONG, "integer");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber((Long)value);
        }
    }

    @JacksonStdImpl
    public static class IntLikeSerializer
    extends Base<Object> {
        static final IntLikeSerializer instance = new IntLikeSerializer();

        public IntLikeSerializer() {
            super(Number.class, JsonParser.NumberType.INT, "integer");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber(((Number)value).intValue());
        }
    }

    @JacksonStdImpl
    public static class IntegerSerializer
    extends Base<Object> {
        public IntegerSerializer(Class<?> type) {
            super(type, JsonParser.NumberType.INT, "integer");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber((Integer)value);
        }

        @Override
        public void serializeWithType(Object value, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
            this.serialize(value, gen, provider);
        }
    }

    @JacksonStdImpl
    public static class ShortSerializer
    extends Base<Object> {
        static final ShortSerializer instance = new ShortSerializer();

        public ShortSerializer() {
            super(Short.class, JsonParser.NumberType.INT, "integer");
        }

        @Override
        public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            gen.writeNumber((Short)value);
        }
    }

    public static abstract class Base<T>
    extends StdScalarSerializer<T>
    implements ContextualSerializer {
        protected final JsonParser.NumberType _numberType;
        protected final String _schemaType;
        protected final boolean _isInt;

        protected Base(Class<?> cls, JsonParser.NumberType numberType, String schemaType) {
            super(cls, false);
            this._numberType = numberType;
            this._schemaType = schemaType;
            this._isInt = numberType == JsonParser.NumberType.INT || numberType == JsonParser.NumberType.LONG || numberType == JsonParser.NumberType.BIG_INTEGER;
        }

        @Override
        @Deprecated
        public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
            return this.createSchemaNode(this._schemaType, true);
        }

        @Override
        public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
            if (this._isInt) {
                this.visitIntFormat(visitor, typeHint, this._numberType);
            } else {
                this.visitFloatFormat(visitor, typeHint, this._numberType);
            }
        }

        @Override
        public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
            JsonFormat.Value format = this.findFormatOverrides(prov, property, this.handledType());
            if (format != null) {
                switch (format.getShape()) {
                    case STRING: {
                        if (this.handledType() == BigDecimal.class) {
                            return NumberSerializer.bigDecimalAsStringSerializer();
                        }
                        return ToStringSerializer.instance;
                    }
                }
            }
            return this;
        }
    }
}

