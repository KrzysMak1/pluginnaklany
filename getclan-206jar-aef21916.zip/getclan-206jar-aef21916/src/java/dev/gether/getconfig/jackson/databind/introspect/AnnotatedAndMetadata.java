/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package dev.gether.getconfig.jackson.databind.introspect;

import dev.gether.getconfig.jackson.databind.introspect.Annotated;

public class AnnotatedAndMetadata<A extends Annotated, M> {
    public final A annotated;
    public final M metadata;

    public AnnotatedAndMetadata(A ann, M md) {
        this.annotated = ann;
        this.metadata = md;
    }

    public static <A extends Annotated, M> AnnotatedAndMetadata<A, M> of(A ann, M md) {
        return new AnnotatedAndMetadata<A, M>(ann, md);
    }
}

