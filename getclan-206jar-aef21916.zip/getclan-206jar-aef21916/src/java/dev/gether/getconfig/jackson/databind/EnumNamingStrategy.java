/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.jackson.databind;

public interface EnumNamingStrategy {
    public String convertEnumToExternalName(String var1);
}

