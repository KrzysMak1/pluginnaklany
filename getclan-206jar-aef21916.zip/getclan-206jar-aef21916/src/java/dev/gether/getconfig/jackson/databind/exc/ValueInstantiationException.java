/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package dev.gether.getconfig.jackson.databind.exc;

import dev.gether.getconfig.jackson.core.JsonParser;
import dev.gether.getconfig.jackson.databind.JavaType;
import dev.gether.getconfig.jackson.databind.JsonMappingException;
import java.io.Closeable;

public class ValueInstantiationException
extends JsonMappingException {
    protected final JavaType _type;

    protected ValueInstantiationException(JsonParser p, String msg, JavaType type, Throwable cause) {
        super((Closeable)p, msg, cause);
        this._type = type;
    }

    protected ValueInstantiationException(JsonParser p, String msg, JavaType type) {
        super(p, msg);
        this._type = type;
    }

    public static ValueInstantiationException from(JsonParser p, String msg, JavaType type) {
        return new ValueInstantiationException(p, msg, type);
    }

    public static ValueInstantiationException from(JsonParser p, String msg, JavaType type, Throwable cause) {
        return new ValueInstantiationException(p, msg, type, cause);
    }

    public JavaType getType() {
        return this._type;
    }
}

