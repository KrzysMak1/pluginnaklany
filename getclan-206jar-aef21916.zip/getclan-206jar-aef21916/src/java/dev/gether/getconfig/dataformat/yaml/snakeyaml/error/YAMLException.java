/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Object
 */
package dev.gether.getconfig.dataformat.yaml.snakeyaml.error;

import dev.gether.getconfig.dataformat.yaml.JacksonYAMLParseException;
import dev.gether.getconfig.jackson.core.JsonParser;

@Deprecated
public class YAMLException
extends JacksonYAMLParseException {
    private static final long serialVersionUID = 1L;

    public YAMLException(JsonParser p, dev.gether.getconfig.snakeyaml.error.YAMLException src) {
        super(p, src.getMessage(), (Exception)((Object)src));
    }

    public static YAMLException from(JsonParser p, dev.gether.getconfig.snakeyaml.error.YAMLException src) {
        return new YAMLException(p, src);
    }
}

