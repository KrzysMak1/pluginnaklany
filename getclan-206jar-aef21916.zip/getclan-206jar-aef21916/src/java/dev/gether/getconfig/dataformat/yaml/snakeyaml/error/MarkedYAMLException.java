/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.dataformat.yaml.snakeyaml.error;

import dev.gether.getconfig.dataformat.yaml.snakeyaml.error.Mark;
import dev.gether.getconfig.dataformat.yaml.snakeyaml.error.YAMLException;
import dev.gether.getconfig.jackson.core.JsonParser;

@Deprecated
public class MarkedYAMLException
extends YAMLException {
    private static final long serialVersionUID = 1L;
    protected final dev.gether.getconfig.snakeyaml.error.MarkedYAMLException _source;

    protected MarkedYAMLException(JsonParser p, dev.gether.getconfig.snakeyaml.error.MarkedYAMLException src) {
        super(p, src);
        this._source = src;
    }

    public static MarkedYAMLException from(JsonParser p, dev.gether.getconfig.snakeyaml.error.MarkedYAMLException src) {
        return new MarkedYAMLException(p, src);
    }

    public String getContext() {
        return this._source.getContext();
    }

    public Mark getContextMark() {
        return Mark.from(this._source.getContextMark());
    }

    public String getProblem() {
        return this._source.getProblem();
    }

    public Mark getProblemMark() {
        return Mark.from(this._source.getProblemMark());
    }
}

