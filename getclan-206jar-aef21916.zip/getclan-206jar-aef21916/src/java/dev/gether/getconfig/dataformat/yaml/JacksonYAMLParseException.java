/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package dev.gether.getconfig.dataformat.yaml;

import dev.gether.getconfig.jackson.core.JsonParseException;
import dev.gether.getconfig.jackson.core.JsonParser;

public class JacksonYAMLParseException
extends JsonParseException {
    private static final long serialVersionUID = 1L;

    public JacksonYAMLParseException(JsonParser p, String msg, Exception e) {
        super(p, msg, (Throwable)e);
    }
}

