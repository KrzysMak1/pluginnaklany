/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package dev.gether.getconfig.dataformat.yaml.snakeyaml.error;

@Deprecated
public class Mark {
    protected final dev.gether.getconfig.snakeyaml.error.Mark _source;

    protected Mark(dev.gether.getconfig.snakeyaml.error.Mark src) {
        this._source = src;
    }

    public static Mark from(dev.gether.getconfig.snakeyaml.error.Mark src) {
        return src == null ? null : new Mark(src);
    }

    public String getName() {
        return this._source.getName();
    }

    public String get_snippet() {
        return this._source.get_snippet();
    }

    public String get_snippet(int indent, int max_length) {
        return this._source.get_snippet(indent, max_length);
    }

    public int getColumn() {
        return this._source.getColumn();
    }

    public int getLine() {
        return this._source.getLine();
    }

    public int getIndex() {
        return this._source.getIndex();
    }
}

